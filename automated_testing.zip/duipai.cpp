#include <bits/stdc++.h>
using namespace std;
int t=20;
int main()
{
	while(t--){
		system("num1.exe");
		system("num2.exe");
		system("code.exe");
		system("num3.exe");
		if(system("fc ans.txt trueans.txt")){
			cout<<"Failed";
			return 0;
		}
	}
	cout<<"Succeeded";
}

