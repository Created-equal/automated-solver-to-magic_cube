#include <bits/stdc++.h>
using namespace std;
string a[12]={"R","Ri","L","Li","B","Bi","D","Di","U","Ui","F","Fi"};
int main()
{
	freopen("num1.txt","w",stdout);
	srand(time(0));
	int n=rand()%1000;
	cout<<n<<endl;
	for(int i=1; i<=n; i++){
		int b=rand()%12;
		cout<<a[b]<<" ";
	}
}

