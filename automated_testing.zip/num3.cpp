#include <bits/stdc++.h>
using namespace std;
void copy(char a[7][10],char b[7][10])
{//a=b
		for(int i=1; i<=6; i++)
    		for(int j=1; j<=9; j++)
        			a[i][j]=b[i][j];
}
char cube[7][10];
char temp[7][10];
void r_R(){
	copy(temp,cube);
	cube[1][3]=temp[6][3];
	cube[1][6]=temp[6][6];
	cube[1][9]=temp[6][9];
	cube[5][3]=temp[1][3];
	cube[5][6]=temp[1][6];
	cube[5][9]=temp[1][9];
	cube[2][1]=temp[5][9];
	cube[2][4]=temp[5][6];
	cube[2][7]=temp[5][3];
	cube[6][3]=temp[2][7];
	cube[6][6]=temp[2][4];
	cube[6][9]=temp[2][1];
	
	cube[4][1]=temp[4][7];
	cube[4][2]=temp[4][4];
	cube[4][3]=temp[4][1];
	cube[4][6]=temp[4][2];
	cube[4][9]=temp[4][3];
	cube[4][8]=temp[4][6];
	cube[4][7]=temp[4][9];
	cube[4][4]=temp[4][8];
	}
void r_Ri()
{
	r_R();
	r_R();
	r_R();
}
void r_L()
{
	copy(temp,cube);
	cube[1][1]=temp[5][1];
	cube[1][4]=temp[5][4];
	cube[1][7]=temp[5][7];
	cube[6][1]=temp[1][1];
	cube[6][4]=temp[1][4];
	cube[6][7]=temp[1][7];
	cube[2][3]=temp[6][7];
	cube[2][6]=temp[6][4];
	cube[2][9]=temp[6][1];
	cube[5][1]=temp[2][9];
	cube[5][4]=temp[2][6];
	cube[5][7]=temp[2][3];

	cube[3][3]=temp[3][1];
	cube[3][6]=temp[3][2];
	cube[3][9]=temp[3][3];
	cube[3][8]=temp[3][6];
	cube[3][7]=temp[3][9];
	cube[3][4]=temp[3][8];
	cube[3][1]=temp[3][7];
	cube[3][2]=temp[3][4];
}
void r_Li()
{
	r_L();
	r_L();
	r_L();
}
void r_B()
{
	copy(temp,cube);
	cube[5][1]=temp[4][3];
	cube[5][2]=temp[4][6];
	cube[5][3]=temp[4][9];
	cube[3][7]=temp[5][1];
	cube[3][4]=temp[5][2];
	cube[3][1]=temp[5][3];
	cube[6][9]=temp[3][7];
	cube[6][8]=temp[3][4];
	cube[6][7]=temp[3][1];
	cube[4][3]=temp[6][9];
	cube[4][6]=temp[6][8];
	cube[4][9]=temp[6][7];
	
	cube[2][1]=temp[2][7];
	cube[2][2]=temp[2][4];
	cube[2][3]=temp[2][1];
	cube[2][6]=temp[2][2];
	cube[2][9]=temp[2][3];
	cube[2][8]=temp[2][6];
	cube[2][7]=temp[2][9];
	cube[2][4]=temp[2][8];
}
void r_Bi()
{
	r_B();
	r_B();
	r_B();
}
void r_D()
{
	copy(temp,cube);
	cube[1][7]=temp[3][7];
	cube[1][8]=temp[3][8];
	cube[1][9]=temp[3][9];
	cube[4][7]=temp[1][7];
	cube[4][8]=temp[1][8];
	cube[4][9]=temp[1][9];
	cube[2][7]=temp[4][7];
	cube[2][8]=temp[4][8];
	cube[2][9]=temp[4][9];
	cube[3][9]=temp[2][9];
	cube[3][8]=temp[2][8];
	cube[3][7]=temp[2][7];
	
	cube[6][1]=temp[6][7];
	cube[6][4]=temp[6][8];
	cube[6][7]=temp[6][9];
	cube[6][8]=temp[6][6];
	cube[6][9]=temp[6][3];
	cube[6][6]=temp[6][2];
	cube[6][3]=temp[6][1];
	cube[6][2]=temp[6][4];
}
void r_Di()
{
	r_D();
	r_D();
	r_D();
}
void r_F()
{
	copy(temp, cube);
	cube[1][3] = temp[1][1];
	cube[1][6] = temp[1][2];
	cube[1][9] = temp[1][3];
	cube[1][2] = temp[1][4];
	cube[1][5] = temp[1][5];
	cube[1][8] = temp[1][6];
	cube[1][1] = temp[1][7];
	cube[1][4] = temp[1][8];
	cube[1][7] = temp[1][9];
        
	cube[4][1] = temp[5][7];
	cube[4][4] = temp[5][8];
	cube[4][7] = temp[5][9];
	cube[6][3] = temp[4][1];
	cube[6][2] = temp[4][4];
	cube[6][1] = temp[4][7];
	cube[3][3] = temp[6][1];
	cube[3][6] = temp[6][2];
	cube[3][9] = temp[6][3];
	cube[5][9] = temp[3][3];
	cube[5][8] = temp[3][6];
	cube[5][7] = temp[3][9];
}
void r_Fi()
{
	r_F();
	r_F();
	r_F();
}
void r_U()
{
	copy(temp, cube);
	cube[5][3] = temp[5][1];
	cube[5][6] = temp[5][2];
	cube[5][9] = temp[5][3];
	cube[5][2] = temp[5][4];
	cube[5][5] = temp[5][5];
	cube[5][8] = temp[5][6];
	cube[5][1] = temp[5][7];
	cube[5][4] = temp[5][8];
	cube[5][7] = temp[5][9];

	cube[1][3] = temp[4][3];
	cube[1][2] = temp[4][2];
	cube[1][1] = temp[4][1];
	cube[3][3] = temp[1][3];
	cube[3][2] = temp[1][2];
	cube[3][1] = temp[1][1];
	cube[2][3] = temp[3][3];
	cube[2][2] = temp[3][2];
	cube[2][1] = temp[3][1];
	cube[4][3] = temp[2][3];
	cube[4][2] = temp[2][2];
	cube[4][1] = temp[2][1];
}
void r_Ui()
{
	r_U();
	r_U();
	r_U();
}
int main()
{
	freopen("ans.txt","w",stdout);
	ifstream fin;
	fin.open("num2.txt");
	for(int i=1; i<=6; i++){
		for(int j=1; j<=9; j++){
			fin>>cube[i][j];
		}
	}
	fin.close();
	fin.open("code.txt");
	string a;
	while(fin>>a){
		if(a=="R") r_R();
		if(a=="Ri") r_Ri();
		if(a=="L") r_L();
		if(a=="Li") r_Li();
		if(a=="B") r_B();
		if(a=="D") r_D();
		if(a=="Bi") r_Bi();
		if(a=="Di") r_Di();
		if(a=="U") r_U();
		if(a=="Ui") r_Ui();
		if(a=="F") r_F();
		if(a=="Fi") r_Fi();
	}
	for(int i=1; i<=6; i++){
		for(int j=1; j<=9; j++){
			cout<<cube[i][j];
		}
		cout<<endl;
	}
}

